<?php
   /*
   Plugin Name: Charts from CSV
   Plugin URI: http://www.whitmanresearch.com
   Description: This plugin adds shortcode to display charts from a certain csv file.
   Version: 0.6
   Author: whitmanresearch
   Author URI: http://www.whitmanresearch.com
   */

// Options page
add_action('admin_menu', 'charts_from_csvs_options',99);
function charts_from_csvs_options() {
    add_menu_page( 'CSV Charts', 'CSV Charts', 'edit_posts', 'wr_options', 'csv_charts_options_display', 'dashicons-chart-pie', 56);
}

// settings
add_action( 'admin_init', 'wr_settings_init' );
function wr_settings_init(  ) { 

	register_setting( 'csvsettings', 'wr_settings' );

	add_settings_section(
		'wr_csvsettings_section', 
		__( '', 'whitmanresearch' ), 
		'wr_settings_section_callback', 
		'csvsettings'
	);
}

function csv_charts_options_display(  ) { 

    $cvSettings = get_option('wr_settings');
	$csvLabels = get_option('wr_chart_labels');

    if(empty($cvSettings)) $cvSettings = array();
    if(empty($csvLabels)) $csvLabels = array();
	?>
	<h1 class="csvs">Charts from CSV
   <button id="addcsv" class="button button-secondary">Add CSV File</button></h1>
    <table id='csvtable' class="widefat">
        <thead>
            <th class="title id">remove</th>
            <th class="title name">File name</th>
            <th class="title sc">Short code</th>
            <th class="title json">JSON</th>
            <th class="title type">Type</th>
            <!--th class="title ylable">Y axis</th-->
            <!--th class="title xlabel">X axis</th-->
            <!--th class="title remove">update labels</th-->
        </thead>
        <tbody>
        <?php
        if(!empty($cvSettings)){
            foreach ($cvSettings as $key => $id){
				
				// labels
				$ylabel = empty($csvLabels[$id]['xlabel']) ? '' : $csvLabels[$id]['xlabel'];
				$xlabel = empty($csvLabels[$id]['ylabel']) ? '' : $csvLabels[$id]['ylabel'];
                $key++;
                echo '<tr>';
                echo     '<td><button data-id="'.$id.'" class="button button-secondary removecsv">x</button></td>';
                echo     '<td>'.basename(wp_get_attachment_url($id)).'</td>';
                echo     '<td data-id="'.$id.'" class="chart-type">[csv_chart id="'.$id.'"]</td>';
				echo     '<td><a href="'.wr_get_json_url($id).'" target="_blank">'.basename(wr_get_json_url($id)).'</a></td>';
                echo     '<td><button class="button button-secondary toggletype">toggle</button></td>';
				echo     '<!--td><input type="text" class="axislabel ylabel" placeholder="label" value="'.$ylabel.'"/></td-->';
				echo     '<!--td><input type="text" class="axislabel xlabel" placeholder="label" value="'.$xlabel.'"/></td-->';
                echo     '<!--td><button data-id="'.$id.'" class="button button-secondary updatelabels">update labels</button></td-->';
                echo '</tr>';
                
            }
            echo '</tbody>';
            echo '</table>';
        }else{
            echo '</tbody>';
            echo '</table>';
            echo '<p>you have no csv files yet.</p>';
         }
}
function wr_settings_section_callback(  ) { 
	echo __( '<p>click the add button to add csv files.</p>', 'whitmanresearch' );
}

// enqueuing assets
add_action('admin_enqueue_scripts', 'wr_enqueue_admin_assets');
function wr_enqueue_admin_assets($hook){
    if ( 'toplevel_page_wr_options' != $hook ) {
        return;
    }
    
    // media uploader
 	if ( ! did_action( 'wp_enqueue_media' ) ) {
		wp_enqueue_media();
	}
    // admin js
    wp_enqueue_script('wr-admin', plugins_url().'/charts-from-csv/assets/js/admin.js', ['jquery'], null, true);
    
    // admin css
    wp_enqueue_style('wr-admin', plugins_url().'/charts-from-csv/assets/css/admin.css');
}

// adding csv files to settings via ajax
add_action('wp_ajax_add_scv_to_settings','add_scv_to_settings');
function add_scv_to_settings(){
    $csvId = $_POST['id'];
    
    if(!empty($csvId)){
        $cvSettings = get_option('wr_settings');
        
        if(empty($cvSettings)) $cvSettings = array();
        
        // check if this file is already in
        $check = false;
        foreach ($cvSettings as $csv){
            if($csv == $csvId){
              $check = true;  
              return;
            } 
        }
        
        // if it doesn't exist then we add it
        if(!$check) {
			array_push($cvSettings,$csvId);
			wr_make_json_from_csv($csvId);
		}
        
        update_option('wr_settings',$cvSettings);
        wp_send_json_success($cvSettings);
        
    }else{
        
        wp_send_json_error();
        
    }
    
}

// adding csv files to settings via ajax
add_action('wp_ajax_wr_update_labels','wr_update_labels');
function wr_update_labels(){
    $csvId = $_POST['id'];
    $ylabel = $_POST['ylabel'];
    $xlabel = $_POST['xlabel'];
    
	$csvLabels = get_option('wr_chart_labels');
        
	if(empty($csvLabels)) $csvLabels = array();
      
    // setting labels
	$csvLabels[$csvId]['xlabel'] = $ylabel;
	$csvLabels[$csvId]['ylabel'] = $xlabel;
        
	update_option('wr_chart_labels',$csvLabels);
	
	wp_send_json_success($csvLabels);
}

// creating json from csv file
function wr_make_json_from_csv($id){
	
	$csvFile = wp_get_attachment_url($id);

	$csvArry = array_map('str_getcsv', file($csvFile));
	$json = array();
	$timeLine = array();
	$counts = array();
	$temperature = array();
	$bpressure = array();
	$rumidity = array();
	// axis labels
	$axisLabels = array();

	foreach ($csvArry as $key => $csvEntry){
		
		if($key == 0){
			// first row of the csv data will be used for the axis labels
			$axisLabels = $csvEntry;
		}else{
			
			// date
			$date =  $csvEntry[0];
			// time
			$time = $csvEntry[1];
			// timestamp
			$timestamp = strtotime ($date.' '.$time);
			// timeline
			// $timeLine[] = date('D M d Y H:i:s O', $timestamp);
			$timeLine[] = $timestamp;

			$counts[] = floatval($csvEntry[2]); 
			$temperature[] = floatval($csvEntry[3]); 
			$bpressure[] = floatval($csvEntry[4]); 
			$rumidity[] = floatval($csvEntry[5]); 
			
		}
	}
	
	$json['xData'] = $timeLine;
	$json['datasets'][0] = array(
							'name' => 'Counts',
							'data' => $counts,
							'unit' => 'counts',
							'type' => 'line',
							'valueDecimals' => 0,
							'axisLabel' => empty($axisLabels[2]) ? '' : $axisLabels[2]
							);

	$json['datasets'][1] = array(
							'name' => 'Temperature',
							'data' => $temperature,
							'unit' => '°C',
							'type' => 'line',
							'valueDecimals' => 0,
							'axisLabel' => empty($axisLabels[3]) ? '' : $axisLabels[3]
							);

	$json['datasets'][2] = array(
							'name' => 'Barometric Pressure',
							'data' => $bpressure,
							'unit' => 'atm',
							'type' => 'line',
							'valueDecimals' => 0,
							'axisLabel' => empty($axisLabels[4]) ? '' : $axisLabels[4]
							);

	$json['datasets'][3] = array(
							'name' => 'Relative Humidity',
							'data' => $rumidity,
							'unit' => '%',
							'type' => 'line',
							'valueDecimals' => 0,
							'axisLabel' => empty($axisLabels[5]) ? '' : $axisLabels[5]
							);
	// adding the xAxis label from the first entry in the titles
	$json['xtitle'] = empty($axisLabels[0]) ? '' : $axisLabels[0];

	
	// creating the csvjson directory
	$upload_dir = wp_upload_dir();
	$json_dir = $upload_dir['basedir'].'/csvjson/';
	if ( ! file_exists( $json_dir ) ) {
		wp_mkdir_p( $json_dir );
	} 

	// creating the json file

	$json_file = fopen($json_dir.$id.'.json', 'w') or die('Unable to open file!');
	fwrite($json_file, json_encode($json));
	fclose($json_file);
	
	$jsonFileUrl = $upload_dir['baseurl'].'/csvjson/'.$id.'.json';
}

// deleting csv files from settings via ajax
add_action('wp_ajax_delete_scv_from_settings','delete_scv_from_settings');
function delete_scv_from_settings(){
    $csvId = $_POST['id'];
    
    if(!empty($csvId)){
        $cvSettings = get_option('wr_settings');
        $csvLabels = get_option('wr_chart_labels');
		
        if(empty($cvSettings)) $cvSettings = array();
        if(empty($csvLabels)) $csvLabels = array();
        
        // check if this file is already in

        foreach ($cvSettings as $key => $csv){
            if($csv == $csvId){
                unset($cvSettings[$key]);
				
				//removing chart label titles
                unset($csvLabels[$csvId]);
            } 
        }
        
        update_option('wr_settings',$cvSettings);
		
        update_option('wr_chart_labels',$csvLabels);
		
		// deleting the json file
		wr_delete_json_by_id($csvId);
        wp_send_json_success($cvSettings);
        
    }else{
        
        wp_send_json_error();
        
    }
    
}

// deleting the json file by id
function wr_delete_json_by_id($id){
	$upload_dir = wp_upload_dir();
	$json_dir = $upload_dir['basedir'].'/csvjson/';
	$json_file = $json_dir.$id.'.json';
	
	unlink($json_file);
}

// get json link by id
function wr_get_json_url($id){
	$upload_dir = wp_upload_dir();
	$json_dir = $upload_dir['baseurl'].'/csvjson/';
	$json_url = $json_dir.$id.'.json';
	
	return $json_url;
}
// deleting a file from the settings if the actual attachement is deleted
add_action('deleted_post', 'wr_deleted_attachement');
function wr_deleted_attachement($id){
    
    $cvSettings = get_option('wr_settings');
    
    if(empty($cvSettings)) $cvSettings = array();

    foreach ($cvSettings as $recordId => $csvId){
        if($csvId == $id){
          unset($cvSettings[$recordId]);
        } 
    }
    // deleting the json file
	wr_delete_json_by_id($id);
    update_option('wr_settings',$cvSettings);
        
}

// function update table rows
add_action('wp_ajax_update_table_rows','update_table_rows');
function update_table_rows(){

    $cvSettings = get_option('wr_settings');
	$csvLabels = get_option('wr_chart_labels');
    $table = '<table id="csvtable" class="widefat">';
    $table .=     '<thead>';
	$table .=	     '<th class="title id">remove</th>';
	$table .=	     '<th class="title name">File name</th>';
	$table .=	     '<th class="title sc">Short code</th>';
	$table .=	     '<th class="title json">JSON</th>';
	$table .=	     '<th class="title type">Type</th>';
	$table .=	     '<!--th class="title ylable">Y axis</th-->';
	$table .=	     '<!--th class="title xlabel">X axis</th-->';
	$table .=	     '<!--th class="title remove">update labels</th-->';
    $table .=     '</thead>';
    $table .=     '<tbody>';
        
    if(!empty($cvSettings)){
        foreach ($cvSettings as $key => $id){
			
			// labels
			$ylabel = empty($csvLabels[$id]['xlabel']) ? '' : $csvLabels[$id]['xlabel'];
			$xlabel = empty($csvLabels[$id]['ylabel']) ? '' : $csvLabels[$id]['ylabel'];
			
            $key++;
            $table .= '<tr>';
            $table .=    '<td><button data-id="'.$id.'" class="button button-secondary removecsv">x</button></td>';
            $table .=    '<td>'.basename(wp_get_attachment_url($id)).'</td>';
            $table .=    '<td data-id="'.$id.'" class="chart-type">[csv_chart id="'.$id.'"]</td>';
            $table .=    '<td><a href="'.wr_get_json_url($id).'" target="_blank">'.basename(wr_get_json_url($id)).'</a></td>';
            $table .=    '<td><button class="button button-secondary toggletype">toggle</button></td>';
			$table .=	 '<!--td><input type="text" class="axislabel ylabel" placeholder="label" value="'.$ylabel.'"/></td-->';
			$table .=	 '<!--td><input type="text" class="axislabel xlabel" placeholder="label" value="'.$xlabel.'"/></td-->';
			$table .=	 '<!--td><button data-id="'.$id.'" class="button button-secondary updatelabels">update labels</button></td-->';
            $table .= '</tr>';

        }
        $table .= '</tbody>';
        $table .= '</table>';
    }else{
        $table .= '</tbody>';
        $table .= '</table>';
        $table .= '<p>you have no csv files yet.</p>';
     }
    
    wp_send_json_success($table);
}

// the shortcode
function wr_csv_chart( $atts ) {
	$atts = shortcode_atts( array('id' => '','type' => ''), $atts, 'csv_chart' );
    $csvUrl = wp_get_attachment_url($atts['id']); 
	$chartContainer = 'csvchart-'.$atts['id'];
	// axis labels
	$csvLabels = get_option('wr_chart_labels');
	$xlabel = empty($csvLabels[$atts['id']]['xlabel']) ? '' : $csvLabels[$atts['id']]['xlabel'];
	$ylabel = empty($csvLabels[$atts['id']]['ylabel']) ? '' : $csvLabels[$atts['id']]['ylabel'];
                           
    if(empty($csvUrl)){
        echo '<p>ERROR! invalid csv id.</p>';
        return;
    }
	
	?>
<p>

<?php 
	// single chart
	if($atts['type'] === 'single'):
?>

	<script>
	jQuery(document).ready(function(){
			/**
			 * In order to synchronize tooltips and crosshairs, override the
			 * built-in events with handlers defined on the parent element.
			 */
			jQuery('.<? echo $chartContainer; ?>').bind('mousemove touchmove touchstart', function (e) {
				var chart,
					point,
					i,
					event;

				for (i = 0; i < Highcharts.charts.length; i = i + 1) {
					chart = Highcharts.charts[i];
					event = chart.pointer.normalize(e.originalEvent); // Find coordinates within the chart
					point = chart.series[0].searchPoint(event, true); // Get the hovered point

					if (point) {
						point.highlight(e);
					}
				}
			});
			/**
			 * Override the reset function, we don't need to hide the tooltips and crosshairs.
			 */
			Highcharts.Pointer.prototype.reset = function () {
				return undefined;
			};

			/**
			 * Highlight a point by showing tooltip, setting hover state and draw crosshair
			 */
			Highcharts.Point.prototype.highlight = function (event) {
				this.onMouseOver(); // Show the hover marker
				this.series.chart.tooltip.refresh(this); // Show the tooltip
				this.series.chart.xAxis[0].drawCrosshair(event, this); // Show the crosshair
			};

			/**
			 * Synchronize zooming through the setExtremes event handler.
			 */
			function syncExtremes(e) {
				var thisChart = this.chart;

				if (e.trigger !== 'syncExtremes') { // Prevent feedback loop
					Highcharts.each(Highcharts.charts, function (chart) {
						if (chart !== thisChart) {
							if (chart.xAxis[0].setExtremes) { // It is null while updating
								chart.xAxis[0].setExtremes(e.min, e.max, undefined, false, { trigger: 'syncExtremes' });
							}
						}
					});
				}
			}

			// Get the data. The contents of the data file can be viewed at
			// https://github.com/highcharts/highcharts/blob/master/samples/data/activity.json
			/**
			 * Add custom date formats
			 */
			jQuery.getJSON('<? echo wr_get_json_url($atts['id']) ?>', function (activity) {
				jQuery.each(activity.datasets, function (i, dataset) {
					if(i == 1) return false;
					// Add X values
					dataset.data = Highcharts.map(dataset.data, function (val, j) {
						return [activity.xData[j], val];
					});

					jQuery('<div class="chart">')
						.appendTo('.<? echo $chartContainer; ?>')
						.highcharts({
							chart: {
							   // marginLeft: 40, // Keep all charts left aligned
								spacingTop: 20,
								spacingBottom: 20
							},
							title: {
								text: dataset.axisLabel,
								align: 'left',
								margin: 0,
								x: 30
							},
							credits: {
								enabled: false
							},
							legend: {
								enabled: false
							},
							xAxis: {
								title: {
									text: activity.xtitle,
								},
								allowDecimals: true,
								type: 'string',
								crosshair: true,
								events: {
									setExtremes: syncExtremes
								},
								labels: {
									formatter: function () {
										var days, hours, minutes, seconds;

											if( this.value == null )
											return "";

										days = ( this.value / 86400 ) >> 0;
										hours = ( this.value % 86400 / 3600 ) >> 0;
										minutes = ( this.value % 3600 / 60 ) >> 0;
										seconds = ( this.value % 60 );    
										seconds = seconds < 10 ? "0" + seconds : seconds;
										minutes = minutes < 10 ? "0" + minutes : minutes;
										hours = hours < 10 ? "0" + hours : hours;

										return hours + ":" + minutes;
									}
								},

							},
							yAxis: {
								title: {
									//text: '<?php echo $ylabel; ?>',
									text: dataset.axisLabel,
								}
							},
							tooltip: {
								positioner: function () {
									return {
										x: this.chart.chartWidth - this.label.width, // right aligned
										y: -1 // align to title
									};
								},
								borderWidth: 0,
								backgroundColor: 'none',
								pointFormat: '{point.y}',
								headerFormat: '',
								shadow: false,
								style: {
									fontSize: '18px'
								},
								//valueDecimals: dataset.valueDecimals
							},
							series: [{
								data: dataset.data,
								name: dataset.name,
								type: dataset.type,
								color: Highcharts.getOptions().colors[i],
								fillOpacity: 0.3,
								tooltip: {
									valueSuffix: ' ' + dataset.unit
								}
							}]
						});
				});
			});

	})	
	</script>
	
<?php 
	// triple chart
	else: 
?>

	<script>
	jQuery(document).ready(function(){
			/**
			 * In order to synchronize tooltips and crosshairs, override the
			 * built-in events with handlers defined on the parent element.
			 */
			jQuery('.<? echo $chartContainer; ?>').bind('mousemove touchmove touchstart', function (e) {
				var chart,
					point,
					i,
					event;

				for (i = 0; i < Highcharts.charts.length; i = i + 1) {
					chart = Highcharts.charts[i];
					event = chart.pointer.normalize(e.originalEvent); // Find coordinates within the chart
					point = chart.series[0].searchPoint(event, true); // Get the hovered point

					if (point) {
						point.highlight(e);
					}
				}
			});
			/**
			 * Override the reset function, we don't need to hide the tooltips and crosshairs.
			 */
			Highcharts.Pointer.prototype.reset = function () {
				return undefined;
			};

			/**
			 * Highlight a point by showing tooltip, setting hover state and draw crosshair
			 */
			Highcharts.Point.prototype.highlight = function (event) {
				this.onMouseOver(); // Show the hover marker
				this.series.chart.tooltip.refresh(this); // Show the tooltip
				this.series.chart.xAxis[0].drawCrosshair(event, this); // Show the crosshair
			};

			/**
			 * Synchronize zooming through the setExtremes event handler.
			 */
			function syncExtremes(e) {
				var thisChart = this.chart;

				if (e.trigger !== 'syncExtremes') { // Prevent feedback loop
					Highcharts.each(Highcharts.charts, function (chart) {
						if (chart !== thisChart) {
							if (chart.xAxis[0].setExtremes) { // It is null while updating
								chart.xAxis[0].setExtremes(e.min, e.max, undefined, false, { trigger: 'syncExtremes' });
							}
						}
					});
				}
			}

			// Get the data. The contents of the data file can be viewed at
			// https://github.com/highcharts/highcharts/blob/master/samples/data/activity.json
			/**
			 * Add custom date formats
			 */
			jQuery.getJSON('<? echo wr_get_json_url($atts['id']) ?>', function (activity) {
				jQuery.each(activity.datasets, function (i, dataset) {
					// Add X values
					dataset.data = Highcharts.map(dataset.data, function (val, j) {
						return [activity.xData[j], val];
					});

					jQuery('<div class="chart">')
						.appendTo('.<? echo $chartContainer; ?>')
						.highcharts({
							chart: {
							   // marginLeft: 40, // Keep all charts left aligned
								spacingTop: 20,
								spacingBottom: 20
							},
							title: {
								text: dataset.axisLabel,
								align: 'left',
								margin: 0,
								x: 30
							},
							credits: {
								enabled: false
							},
							legend: {
								enabled: false
							},
							xAxis: {
								title: {
									text: activity.xtitle,
								},
								allowDecimals: true,
								type: 'string',
								crosshair: true,
								events: {
									setExtremes: syncExtremes
								},
								labels: {
									formatter: function () {
										var days, hours, minutes, seconds;

											if( this.value == null )
											return "";

										days = ( this.value / 86400 ) >> 0;
										hours = ( this.value % 86400 / 3600 ) >> 0;
										minutes = ( this.value % 3600 / 60 ) >> 0;
										seconds = ( this.value % 60 );    
										seconds = seconds < 10 ? "0" + seconds : seconds;
										minutes = minutes < 10 ? "0" + minutes : minutes;
										hours = hours < 10 ? "0" + hours : hours;

										return hours + ":" + minutes;
									}
								},

							},
							yAxis: {
								title: {
									//text: '<?php echo $ylabel; ?>',
									text: dataset.axisLabel,
								}
							},
							tooltip: {
								positioner: function () {
									return {
										x: this.chart.chartWidth - this.label.width, // right aligned
										y: -1 // align to title
									};
								},
								borderWidth: 0,
								backgroundColor: 'none',
								pointFormat: '{point.y}',
								headerFormat: '',
								shadow: false,
								style: {
									fontSize: '18px'
								},
								//valueDecimals: dataset.valueDecimals
							},
							series: [{
								data: dataset.data,
								name: dataset.name,
								type: dataset.type,
								color: Highcharts.getOptions().colors[i],
								fillOpacity: 0.3,
								tooltip: {
									valueSuffix: ' ' + dataset.unit
								}
							}]
						});
				});
			});

	})	
	</script>

<?php endif; ?>

	<div class="<? echo $chartContainer; ?>"></div>
</p>
	<?php
}
add_shortcode( 'csv_chart', 'wr_csv_chart' );

// enqueue frontend scripts
add_action('wp_enqueue_scripts', 'wr_enqueue_frontend_assesst');
function wr_enqueue_frontend_assesst(){
	
	// frontend style
    wp_enqueue_style('wr-charts', plugins_url().'/charts-from-csv/assets/css/frontend.css');
	
	// frontend js
    wp_enqueue_script('wr-moment', plugins_url().'/charts-from-csv/assets/js/moment.js', ['jquery'], null, false);
	wp_enqueue_script('wr-highcharts', 'https://code.highcharts.com/highcharts.js', ['jquery'], null, false);
	wp_enqueue_script('wr-highcharts-data', 'http://code.highcharts.com/modules/data.js', ['jquery','highcharts'], null, false);
}