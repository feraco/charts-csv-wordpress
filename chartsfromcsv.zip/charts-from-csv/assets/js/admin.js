(function($){
    
    $(document).ready(function(){
       
        // add csv button
        $('body').on('click', '#addcsv', function(e){
            e.preventDefault();

                var button = $(this),
                    custom_uploader = wp.media({
                title: 'Insert CSV file',
                library : {
                    type : 'text/csv,text'
                },
                button: {
                    text: 'Use this CSV' 
                },
                multiple: false 
            }).on('select', function() { 
                var csv = custom_uploader.state().get('selection').first().toJSON();
                addCsv(csv.id);
            })
            .open();
        });
        
   
    // delete csv button
        $('body').on('click', '.removecsv', function(e){
            e.preventDefault();
            var self = $(e.target);
            var csvId = self.attr('data-id');
            deleteCsv(csvId,e);
        });


    // adding the csv to the settings via ajax
    function addCsv(csvId){
        var btn = $('#addcsv');
        var btnTxt = $('#addcsv').text();

      jQuery.ajax({
         type : "post",
         dataType : "json",
         url : ajaxurl,
         data : {
             action: "add_scv_to_settings",
             id: csvId 
         },
         beforeSend: function() {
             btn.addClass('updating-message disabled').text('updating...');
         },
         success: function(response) {
            btn.removeClass('updating-message disabled').text(btnTxt);
            updateCsvTable();
			wrJsonFromCsv(csvId);
         }
      }); 
    }
    
    // deleting the csv from the settings via ajax
    function deleteCsv(csvId,e){
        var btn = $(e.target);

      jQuery.ajax({
         type : "post",
         dataType : "json",
         url : ajaxurl,
         data : {
             action: "delete_scv_from_settings",
             id: csvId 
         },
         beforeSend: function() {
             btn.addClass('updating-message disabled').text('');
         },
         success: function(response) {
            updateCsvTable();
         }
      }); 
    }
    
    // updating the csv table
    function updateCsvTable(){
      var table = $('#csvtable');
      jQuery.ajax({
         type : "post",
         dataType : "json",
         url : ajaxurl,
         data : {
             action: "update_table_rows",
         },
         beforeSend: function() {
             table.addClass('loading disabled');
         },
         success: function(response) {
            table.removeClass('loading disabled');
            table.next('p').remove();
            table.replaceWith(response.data);
         }
      }); 
    }
	
    // creating json from csv
    function wrJsonFromCsv(id){
      jQuery.ajax({
         type : 'json',
         dataType : 'json',
         url : ajaxurl,
         data : {
             action: 'wr_make_json_from_csv',
             id: id,
         }
      }); 
    }

	// updatin labels
	$('body').on('click', '.updatelabels', function(){
		  var self = $(this);
		  var selfText = $(this).text();
		  var id = self.attr('data-id');
		  var ylabel = self.closest('tr').find('.ylabel').val();
		  var xlabel = self.closest('tr').find('.xlabel').val();
		
		  $.ajax({
			 type : "post",
			 dataType : "json",
			 url : ajaxurl,
			 data : {
				 action: "wr_update_labels",
				 id: id,
				 ylabel: ylabel,
				 xlabel: xlabel,
			 },
			 beforeSend: function() {
				 self.addClass('updating-message').text('updating...');
			 },
			 success: function(response) {
				self.removeClass('updating-message').text(selfText);
			 }
		  }); 
	});
	
	// remove all 
	$('body').on('click', '#removeall', function(){
		$('.removecsv').each(function(){
			$(this).trigger('click');
		})
	});
		
	// remove all 
	$('body').on('click', '#updatealllabels', function(){
		$('.updatelabels').each(function(){
			$(this).trigger('click');
		})
	});
 });
	
	// chart type short code
	$(document.body).on('click', '.toggletype', function(){
		var self = $(this);
		var code = self.closest('tr').find('td.chart-type');
		var id = code.attr('data-id');
		
		if(code.hasClass('single-chart')){
			
			code.text('[csv_chart id="' + id + '"]');
			code.removeClass('single-chart');
		}else{
			
			code.text('[csv_chart id="' + id + '" type="single"]');
			code.addClass('single-chart');
			
			
		}
	})

}(jQuery))